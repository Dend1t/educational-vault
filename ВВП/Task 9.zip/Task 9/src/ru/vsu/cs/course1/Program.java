package ru.vsu.cs.course1;

import ru.vsu.cs.util.ArrayUtils;
import ru.vsu.cs.util.SwingUtils;

import java.io.PrintStream;
import java.util.Locale;


public class Program {

    public static class InputArgs {
        public String inputFile;
        public String outputFile;
        public boolean delRowColcreateNewList;
        public boolean error;
        public boolean help;
        public boolean window;
    }

    public static InputArgs parseCmdArgs(String[] args) {
        InputArgs params = new InputArgs();
        if (args.length > 0) {
            if (args[0].equals("--help")) {
                params.help = true;
                return params;
            }
            if (args[0].equals("--window")) {
                params.window = true;
                return params;
            }
            if (!args[0].equals("-r") ) {
                params.error = true;
                params.help = true;
                return params;
            }
            if (args[0].equals("-r")) {
                params.delRowColcreateNewList = true;
            }
            if (args.length < 2) {
                params.help = true;
                params.error = true;
                return params;
            }

            params.inputFile = args[1];
            if (args.length > 2) {
                params.outputFile = args[2];
            }
        } else {
            params.help = true;
            params.error = true;
        }
        return params;
    }

    public static void winMain() throws Exception {
        //SwingUtils.setLookAndFeelByName("Windows");
        Locale.setDefault(Locale.ROOT);
        //UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        SwingUtils.setDefaultFont("Microsoft Sans Serif", 18);

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FrameMain().setVisible(true);
            }
        });
    }

    public static void main(String[] args) throws Exception {
        InputArgs params = parseCmdArgs(args);
        if (params.help) {
            PrintStream out = params.error ? System.err : System.out;
            out.println("Usage:");
            out.println("  <cmd> args <input-file> (<output-file>)");
            out.println("    -r  // return new array");
            out.println("  <cmd> --help");
            out.println("  <cmd> --window  // show window");
            System.exit(params.error ? 1 : 0);
        }
        if (params.window) {
            winMain();
        } else {
            try {
                int[] arr = ArrayUtils.readIntArrayFromFile(params.inputFile);
                if (arr == null) {
                    System.err.printf("Can't read array from \"%s\"%n", params.inputFile);
                    System.exit(2);
                }
                if (params.delRowColcreateNewList) {
                    arr = Task.listToArr(Task.createNewList(Task.arrToList(arr)));
                }
                PrintStream out = (params.outputFile != null) ? new PrintStream(params.outputFile) : System.out;
                out.println(ArrayUtils.toString(arr));
                out.close();
            } catch (Exception e) {
                int[] arr = new int[0];
                PrintStream out = (params.outputFile != null) ? new PrintStream(params.outputFile) : System.out;
                out.println(ArrayUtils.toString(arr));
                out.close();
            }
        }
    }
}
