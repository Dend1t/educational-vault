//Вернуть в виде списка самую длинную неубывающую подпоследовательность подряд
//        идущих чисел в переданном списке. Если можно выделить несколько таких
//        подпоследовательностей одинаковой длины, то вернуть ту, сумма элементов которой
//        будет максимальна. Если и сумма элементов совпадает, то вернуть первую (от начала
//        списка) такую подпоследовательность.
package ru.vsu.cs.course1;

import java.util.ArrayList;
import java.util.List;

public class Task {
    public static List<Integer> createNewList(List<Integer> list){
        if(list.size()==0){
            return list;
        }
        List<Integer> max = new ArrayList<Integer>();
        max.add(getByIndex(list,0));
        List<Integer> lastMax = new ArrayList<Integer>();
        int sumMax=0;
        for(int i = 0; i<list.size()-1; i++){
            if(getByIndex(list,i) <= getByIndex(list,i+1)){
                max.add(getByIndex(list,i+1));
            }
            else {
                if(lastMax.size() == max.size()){
                    if(sumList(max)>sumMax){
                        sumMax=sumList(lastMax);
                        lastMax=max;
                        max = new ArrayList<>();
                        max.add(getByIndex(list,i+1));
                    }
                    else{
                        max = new ArrayList<>();
                        max.add(getByIndex(list,i+1));
                    }
                }
                else if(max.size() > lastMax.size()){
                    lastMax=max;
                    sumMax=sumList(lastMax);
                    max = new ArrayList<>();
                    max.add(getByIndex(list,i+1));
                }
                else{
                    max =new  ArrayList<>();
                    max.add(getByIndex(list,i+1));
                }
            }
        }

        if(lastMax.size() == max.size()){
            if(sumList(max)>sumMax){
                lastMax=max;
            }
        }
        else if(max.size() > lastMax.size()){
            lastMax=max;
        }
        return lastMax;
    }
    public static int getByIndex(List<Integer> list, int ind){
        int i = 0;
        for(int x : list){
            if(ind==i){
                return x;
            }
            i++;
        }
        return i;
    }
    public static int sumList(List<Integer> list){
        int sum = 0;
        for(int x : list){
            sum+=x;
        }
        return sum;
    }
    public static int[] listToArr(List<Integer> list){
        int[] arr = new int[list.size()];
        int i = 0;
        for(int x:list){
            arr[i] = x;
            i++;
        }
        return arr;
    }
    public static List<Integer> arrToList(int[] arr){
        List<Integer> list = new ArrayList<Integer>();
        for(int x:arr){
            list.add(x);
        }
        return list;
    }
}
