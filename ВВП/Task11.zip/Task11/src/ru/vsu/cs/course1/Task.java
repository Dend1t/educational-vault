//(*) Из текста выбрать (в виде списка) без повторений все email-адреса. За email-адрес
//будет принимать любой фрагмент вида X@X, где X – любая последовательность букв
//        английского алфавита, цифр, а также символов точка, '-' и '_' (естественно, первым и
//последним символом не может быть точка).
package ru.vsu.cs.course1;


import java.util.*;

public class Task {
    public static ArrayList<String> findEmails(String text) {
        int space1;
        ArrayList<String> emails = new ArrayList<>();
        int space2 = 0;
        int end = text.length() - 1;
        for (int i = 0; i <= end; i++) {
            if (text.indexOf(" ", i) != -1) {
                space1 = i;
                i = text.indexOf(" ", i);
                space2 = i;
                if (text.indexOf('\n', space1) < space2 && text.indexOf('\n', space1) != -1) {
                    i = text.indexOf('\n', space1);
                    space2 = text.indexOf('\n', space1);
                }
                if (text.indexOf('\r', space1) < space2 && text.indexOf('\r', space1) != -1) {
                    if (text.indexOf('\r', space1) + 1 == text.indexOf('\n', space1)) {
                        space2 = text.indexOf('\r', space1);
                        i = text.indexOf('\n', space1);
                    } else {
                        space2 = text.indexOf('\r', space1);
                        i = text.indexOf('\r', space1);
                    }
                }
                int minLength = space2 - space1 - symCheck(text.charAt(space1)) - symCheck(text.charAt(space2 - 1));
                if (minLength > 2) {
                    String possibleEmail = text.substring(
                            space1 + symCheck(text.charAt(space1)),
                            space2 - symCheck(text.charAt(space2 - 1))
                    );
                    boolean isEmail = checkEmail(possibleEmail);
                    if (isEmail) {
                        emails.add(possibleEmail);
                    }
                }
            }
        }
        int minLength = end - space2 - symCheck(text.charAt(space2)) - symCheck(text.charAt(end - 1));
        if (minLength > 2) {
            String possibleEmail = text.substring(
                    space2 + symCheck(text.charAt(space2)),
                    end - symCheck(text.charAt(end - 1))
            );
            if (checkEmail(possibleEmail)) {
                emails.add(possibleEmail);
            }
        }

        Set<String> sortEmails = new LinkedHashSet<>(emails);

        return new ArrayList<>(sortEmails);
    }

    public static int symCheck(char c) {
        if (Character.isLetter(c) || Character.isDigit(c)) {
            return 0;
        }
        return 1;
    }

    public static boolean checkEmail(String possibleEmail) {
        int atCount = 0;
        char[] word = possibleEmail.toCharArray();
        if (word[0] == '@' || word[word.length - 1] == '@') {
            return false;
        }
        for (int i = 0; i < word.length; i++) {
            char x = possibleEmail.charAt(i);
            if (!Character.isDigit(x)) {
                if (!((x >= 'a' && x <= 'z') || (x >= 'A' && x <= 'Z'))) {
                    if (x != '-' && x != '_' && x != '@' && x != '.') {
                        return false;
                    }
                }
            }
            if (x == '@') {
                atCount++;
            }
        }

        return atCount == 1;
    }

    public static String[][] listToArr(ArrayList<String> list) {
        String[][] arr = new String[list.size()][1];
        int i = 0;
        for (String x : list) {
            arr[i][0] = x;
            i++;
        }
        return arr;
    }

}
