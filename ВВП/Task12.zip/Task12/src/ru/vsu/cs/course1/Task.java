package ru.vsu.cs.course1;

import java.io.File;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;

public class Task {

    public static void genMaxDepthElements(String path, String mask,
                                           Consumer<String> callback) {
        File dir = new File(path);
        if (!dir.exists() || !dir.isDirectory()) return;

        int maxDepth = findMaxDepth(dir, 0, mask);
        printMaxDepth(dir, 0, maxDepth, mask, callback);
    }

    private static int findMaxDepth(File dir, int depth, String mask) {
        int max = -1;
        File[] files = dir.listFiles();
        if (files == null) return -1;

        for (int i = 0; i < files.length; i++) {
            File file = files[i];

            if (file.isFile()) {
                if (isMatchWithCache(file.getName(), mask)) {
                    if (depth + 1 > max)
                        max = depth + 1;
                }
            } else {
                int d = findMaxDepth(file, depth + 1, mask);
                if (d > max)
                    max = d;
            }
        }
        return max;
    }

    private static void printMaxDepth(File dir, int depth, int maxDepth,
                                      String mask, Consumer<String> callback) {
        File[] files = dir.listFiles();
        if (files == null) return;

        for (int i = 0; i < files.length; i++) {
            File file = files[i];

            if (file.isFile()) {
                if (depth + 1 == maxDepth && isMatchWithCache(file.getName(), mask)) {
                    callback.accept(file.getAbsolutePath());
                }
            } else {
                printMaxDepth(file, depth + 1, maxDepth, mask, callback);
            }
        }
    }

    public static boolean isMatchWithCache(String str, String pattern) {
        return isMatchWithCache(str, pattern, 0, 0, new HashMap<>());
    }

    private static boolean isMatchWithCache(String str, String pattern,
                                            int strPos, int patternPos,
                                            Map<String, Boolean> cache) {

        String key = strPos + "," + patternPos;
        if (cache.containsKey(key))
            return cache.get(key);

        boolean result;

        if (patternPos == pattern.length()) {
            result = strPos == str.length();
        } else if (pattern.charAt(patternPos) == '*') {
            result =
                    (strPos < str.length() &&
                            isMatchWithCache(str, pattern, strPos + 1, patternPos, cache))
                            ||
                            isMatchWithCache(str, pattern, strPos, patternPos + 1, cache);
        } else if (strPos < str.length() &&
                (pattern.charAt(patternPos) == '?' ||
                        pattern.charAt(patternPos) == str.charAt(strPos))) {

            result = isMatchWithCache(str, pattern,
                    strPos + 1, patternPos + 1, cache);
        } else {
            result = false;
        }

        cache.put(key, result);
        return result;
    }
}
