//Создать новый двумерный массив чисел, исключив из переданного двумерного массива
//все строки и столбцы, содержащие максимальные и минимальные элементы среди всех
//элементов переданного массива.
package ru.vsu.cs.course1;


public class Task {
    public static void Process(int[][] arr2) {
        for (int r = 0; r < arr2.length; r++) {
            for (int c = 0; c < arr2[r].length; c++) {
                arr2[r][c]++;
            }
        }
    }

    public static int[][] Process2(int[][] arr2) {
        int[][] res = new int[2][2];
        for (int r = 0; r < Math.min(arr2.length, 2); r++) {
            for (int c = 0; c < Math.min(arr2[0].length, 2); c++) {
                res[r][c] = arr2[r][c];
            }
        }
        return res;
    }


    public static int[][] delRowCol(int[][] arr2){
        int min = arr2[0][0];
        int max = arr2[0][0];

        for (int x = 0; x < arr2.length; x++) {
            for (int y = 0; y < arr2[x].length; y++) {
                if (arr2[x][y] < min) {
                    min = arr2[x][y];
                }
                if (arr2[x][y] > max) {
                    max = arr2[x][y];
                }
            }
        }

        int newX = 0;
        int newY = 0;

        int[][] newArr = new int[arr2.length - 1][arr2[arr2.length - 1].length - 1];

        for (int[] ints : arr2) {
            if (detectRow(ints, min, max)) {
                newY = 0;
                for (int y = 0; y < ints.length; y++) {
                    if (detectColumn(arr2, min, max, y)) {
                        newArr[newX][newY] = ints[y];
                        newY += 1;
                    }
                }
                newX += 1;
            }
        }
        newArr = trimMatrix(newArr, newX, newY);
        return newArr;
    }

    public static boolean detectRow(int[] arr2, int min, int max) {
        for (int i : arr2) {
            if (i == min || i == max) {
                return false;
            }
        }
        return true;
    }
    public static boolean detectColumn(int[][] arr2, int min, int max, int y) {
        for (int[] ints : arr2) {
            if (ints[y] == min || ints[y] == max) {
                return false;
            }
        }
        return true;
    }

    public static int[][] trimMatrix(int[][] arr2, int rows, int cols) {
         if (arr2 == null || rows <= 0 || cols <= 0 || rows > arr2.length) {
            return new int[0][0];
        }

        int[][] trimmed = new int[rows][cols];

        for (int i = 0; i < rows; i++) {
            int copyLength = Math.min(cols, arr2[i].length);
            System.arraycopy(arr2[i], 0, trimmed[i], 0, copyLength);
        }

        return trimmed;
    }

}
