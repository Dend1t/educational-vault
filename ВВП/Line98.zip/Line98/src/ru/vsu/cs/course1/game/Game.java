package ru.vsu.cs.course1.game;

import java.io.File;
import java.io.PrintWriter;
import java.util.*;

public class Game {

    private final Random rnd = new Random();

    private int[][] field;
    private List<int[]> freeCells;
    private int colorCount;

    public int difficulty;
    public int score;

    private int highScore;

    public int pickedColor;
    private int pickedRow = -1;
    private int pickedCol = -1;

    public boolean incorrectMove;

    public void newGame(int rowCount, int colCount, int colorCount) {
        field = new int[rowCount][colCount];
        this.colorCount = colorCount;

        pickedColor = 0;
        pickedRow = -1;
        pickedCol = -1;
        score = 0;
        incorrectMove = false;

        loadHighScore();

        freeCells = new ArrayList<>();
        for (int i = 0; i < rowCount; i++) {
            for (int j = 0; j < colCount; j++) {
                freeCells.add(new int[]{i, j});
            }
        }

        difficulty = (int) (Math.max(rowCount, colCount)
                / Math.sqrt(Math.min(rowCount, colCount)));

        for (int i = 0; i < difficulty && !freeCells.isEmpty(); i++) {
            int[] c = freeCells.remove(rnd.nextInt(freeCells.size()));
            field[c[0]][c[1]] = rnd.nextInt(colorCount) + 1;
        }
    }

    public void leftMouseClick(int row, int col) {
        incorrectMove = false;

        if (!isInside(row, col)) return;
        if (field[row][col] == 0) return;

        pickedColor = field[row][col];
        pickedRow = row;
        pickedCol = col;
    }

    public void rightMouseClick(int row, int col) {
        incorrectMove = false;

        if (!isInside(row, col)
                || field[row][col] != 0
                || pickedColor == 0
                || !canReach(pickedRow, pickedCol, row, col)) {
            incorrectMove = true;
            return;
        }

        field[row][col] = pickedColor;
        field[pickedRow][pickedCol] = 0;
        freeCells.add(new int[]{pickedRow, pickedCol});

        for (int i = 0; i < freeCells.size(); i++) {
            int[] c = freeCells.get(i);
            if (c[0] == row && c[1] == col) {
                freeCells.remove(i);
                break;
            }
        }

        pickedColor = 0;
        pickedRow = -1;
        pickedCol = -1;

        boolean removed = false;

        for (int x = 0; x < getRowCount(); x++) {
            for (int y = 0; y < getColCount(); y++) {
                if (removeLine(x, y, true)) removed = true;
                if (removeLine(x, y, false)) removed = true;
            }
        }

        if (!removed) {
            for (int i = 0; i < difficulty && !freeCells.isEmpty(); i++) {
                int[] c = freeCells.remove(rnd.nextInt(freeCells.size()));
                field[c[0]][c[1]] = rnd.nextInt(colorCount) + 1;
            }
        }
    }

    private boolean removeLine(int row, int col, boolean rowOrCol) {
        if (!isInside(row, col)) return false;

        int color = field[row][col];
        if (color == 0) return false;

        int len = 1;
        if (rowOrCol) {
            while (isInside(row + len, col)
                    && field[row + len][col] == color) {
                len++;
            }
        } else {
            while (isInside(row, col + len)
                    && field[row][col + len] == color) {
                len++;
            }
        }

        if (len < 5) return false;
        for (int i = 0; i < len; i++) {
            int resultRow = rowOrCol ? row + i : row;
            int resultCol = rowOrCol ? col : col + i;
            field[resultRow][resultCol] = 0;
            freeCells.add(new int[]{resultRow, resultCol});
        }

        score += len;
        return true;
    }

    private boolean canReach(int startRow, int startCol, int lastRow, int lastCol) {
        boolean[][] passedCords = new boolean[getRowCount()][getColCount()];
        return walk(startRow, startCol, lastRow, lastCol, passedCords);
    }

    private boolean walk(int row, int col, int thatRow, int thatCol, boolean[][] passedCords) {
        if (!isInside(row, col) || passedCords[row][col]) return false;
        if (row == thatRow && col == thatCol) return true;
        if (field[row][col] != 0 && !(row == pickedRow && col == pickedCol)) return false;

        passedCords[row][col] = true;

        return walk(row + 1, col, thatRow, thatCol, passedCords)
                || walk(row - 1, col, thatRow, thatCol, passedCords)
                || walk(row, col + 1, thatRow, thatCol, passedCords)
                || walk(row, col - 1, thatRow, thatCol, passedCords);
    }

    public boolean isGameOver() {
        return freeCells.isEmpty();
    }

    public String getEndGameMessage() {
        if (score > highScore) {
            highScore = score;
            saveHighScore();
            return "АЙ ХОРОШ СИГМА БОЙЧЕК \n" +
                    "НОВАЯ РЕКОРДА " + score;
        }

        if (score <= highScore / 4) {
            return "Ты лузер! \n" +
                    "Даже не подходи близко к " + highScore + '\n' +
                    "Со своими нищими " + score;
        }

        if (score < (highScore / 4 * 3)) {
            return "Попробуй ещё \n" +
                    "Лучший рекорд " + highScore + '\n' +
                    "Твой счёт " + score;
        }


        return "Почти получилось! \n" +
                "Ну посмотри сколько тебе не хватило до: " + highScore + '=' + (highScore - score) + '\n' +
                "C твоими то " + score + " на раз - два наберёшь";
    }

    private void loadHighScore() {
        try {
            File f = new File("highscore.txt");
            if (!f.exists()) {
                highScore = 0;
                return;
            }
            try (Scanner scanner = new Scanner(f)) {
                highScore = scanner.hasNextInt() ? scanner.nextInt() : 0;
            }
        } catch (Exception e) {
            highScore = 0;
        }
    }

    private boolean isInside(int row, int col) {
        return row >= 0 && row < getRowCount() && col >= 0 && col < getColCount();
    }

    public int getRowCount() {
        return field.length;
    }

    public int getColCount() {
        return field[0].length;
    }

    public int getCell(int r, int c) {
        return isInside(r, c) ? field[r][c] : 0;
    }

    private void saveHighScore() {
        try (PrintWriter pw = new PrintWriter("highscore.txt")) {
            pw.println(highScore);
        } catch (Exception ignored) {
        }
    }
}
