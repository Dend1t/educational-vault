package ru.vsu.cs.course1.game;

import com.intellij.uiDesigner.core.GridConstraints;
import com.intellij.uiDesigner.core.GridLayoutManager;
import ru.vsu.cs.util.DrawUtils;
import ru.vsu.cs.util.JTableUtils;
import ru.vsu.cs.util.SwingUtils;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import java.awt.*;
import java.awt.event.*;

public class MainForm extends JFrame {
    private JPanel panelMain;
    private JTable tableGameField;
    private JLabel labelStatus;

    private static final int DEFAULT_COL_COUNT = 9;
    private static final int DEFAULT_ROW_COUNT = 9;
    private static final int DEFAULT_COLOR_COUNT = 5;
    private static final int DEFAULT_GAP = 8;
    private static final int DEFAULT_CELL_SIZE = 70;

    private static final Color[] COLORS = {
            Color.BLUE, Color.RED, Color.YELLOW, Color.GREEN, Color.MAGENTA,
            Color.CYAN, Color.ORANGE, Color.PINK, Color.WHITE, Color.GRAY
    };

    private GameParams params = new GameParams(DEFAULT_ROW_COUNT, DEFAULT_COL_COUNT, DEFAULT_COLOR_COUNT);
    private Game game = new Game();

    private int selectedRow = -1;
    private int selectedCol = -1;

    private ParamsDialog dialogParams;

    public MainForm() {
        setTitle("Line98");
        setContentPane(panelMain);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        setJMenuBar(createMenuBar());

        tableGameField.setRowHeight(DEFAULT_CELL_SIZE);
        JTableUtils.initJTableForArray(tableGameField, DEFAULT_CELL_SIZE, false, false, false, false);
        tableGameField.setIntercellSpacing(new Dimension(0, 0));
        tableGameField.setEnabled(false);

        tableGameField.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            final class DrawComponent extends Component {
                int row, column;

                @Override
                public void paint(Graphics g) {
                    Graphics2D g2d = (Graphics2D) g;
                    paintCell(row, column, g2d, getWidth() - 2, getHeight() - 2);
                }
            }

            DrawComponent comp = new DrawComponent();

            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                                                           boolean isSelected, boolean hasFocus,
                                                           int row, int column) {
                comp.row = row;
                comp.column = column;
                return comp;
            }
        });

        tableGameField.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                int row = tableGameField.rowAtPoint(e.getPoint());
                int col = tableGameField.columnAtPoint(e.getPoint());

                if (SwingUtilities.isLeftMouseButton(e)) {
                    selectedRow = row;
                    selectedCol = col;
                    game.leftMouseClick(row, col);
                }

                if (SwingUtilities.isRightMouseButton(e)) {
                    game.rightMouseClick(row, col);
                    if (!game.incorrectMove) {
                        selectedRow = -1;
                        selectedCol = -1;
                    }
                }

                updateView();
            }
        });


        newGame();
        updateWindowSize();
        dialogParams = new ParamsDialog(params, tableGameField, e -> newGame());
    }

    private void paintCell(int row, int column, Graphics2D g2d, int w, int h) {
        int value = game.getCell(row, column);
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        if (value > 0) {
            Color color = COLORS[value - 1];
            int size = Math.min(w, h);
            int b = (int) (size * 0.1);

            g2d.setColor(color);
            g2d.fillRoundRect(b, b, size - 2 * b, size - 2 * b, b * 3, b * 3);
            g2d.setColor(Color.DARK_GRAY);
            g2d.drawRoundRect(b, b, size - 2 * b, size - 2 * b, b * 3, b * 3);

            g2d.setFont(new Font("Comic Sans MS", Font.BOLD, size - 2 * b));
            g2d.setColor(DrawUtils.getContrastColor(color));
            DrawUtils.drawStringInCenter(g2d, g2d.getFont(), String.valueOf(value),
                    0, 0, w, (int) (h * 0.95));
        }

        if (row == selectedRow && column == selectedCol) {
            g2d.setColor(game.incorrectMove ? Color.RED : Color.BLACK);
            g2d.setStroke(new BasicStroke(3));
            g2d.drawRect(1, 1, w - 3, h - 3);
        }
    }

    private void newGame() {
        game.newGame(params.getRowCount(), params.getColCount(), params.getColorCount());
        JTableUtils.resizeJTable(tableGameField,
                game.getRowCount(), game.getColCount(),
                tableGameField.getRowHeight(), tableGameField.getRowHeight()
        );
        selectedRow = -1;
        selectedCol = -1;
        updateView();
    }

    private void updateView() {
        labelStatus.setText("Счёт: " + game.score);

        if (game.isGameOver()) {
            SwingUtils.showInfoMessageBox(
                    game.getEndGameMessage(),
                    "Игра окончена"
            );
        }

        tableGameField.repaint();
    }

    private void updateWindowSize() {
        int menuSize = getJMenuBar() != null ? getJMenuBar().getHeight() : 0;
        SwingUtils.setFixedSize(
                this,
                tableGameField.getWidth() + 2 * DEFAULT_GAP + 60,
                tableGameField.getHeight() + panelMain.getY() + labelStatus.getHeight()
                        + menuSize + 3 * DEFAULT_GAP + 60
        );
        setMaximumSize(null);
        setMinimumSize(null);
    }

    private JMenuBar createMenuBar() {
        JMenuBar bar = new JMenuBar();
        JMenu gameMenu = new JMenu("Игра");

        gameMenu.add(new JMenuItem(new AbstractAction("Новая") {
            public void actionPerformed(ActionEvent e) {
                newGame();
            }
        }));

        gameMenu.add(new JMenuItem(new AbstractAction("Параметры") {
            public void actionPerformed(ActionEvent e) {
                dialogParams.updateView();
                dialogParams.setVisible(true);
            }
        }));

        bar.add(gameMenu);
        return bar;
    }

    {
// GUI initializer generated by IntelliJ IDEA GUI Designer
// >>> IMPORTANT!! <<<
// DO NOT EDIT OR ADD ANY CODE HERE!
        $$$setupUI$$$();
    }

    /**
     * Method generated by IntelliJ IDEA GUI Designer
     * >>> IMPORTANT!! <<<
     * DO NOT edit this method OR call it in your code!
     *
     * @noinspection ALL
     */
    private void $$$setupUI$$$() {
        panelMain = new JPanel();
        panelMain.setLayout(new GridLayoutManager(2, 1, new Insets(10, 10, 10, 10), -1, 10));
        final JScrollPane scrollPane1 = new JScrollPane();
        panelMain.add(scrollPane1, new GridConstraints(0, 0, 1, 1, GridConstraints.ANCHOR_CENTER, GridConstraints.FILL_BOTH, GridConstraints.SIZEPOLICY_CAN_SHRINK | GridConstraints.SIZEPOLICY_WANT_GROW, GridConstraints.SIZEPOLICY_CAN_SHRINK | GridConstraints.SIZEPOLICY_WANT_GROW, null, null, null, 0, false));
        tableGameField = new JTable();
        scrollPane1.setViewportView(tableGameField);
        labelStatus = new JLabel();
        labelStatus.setText("Label");
        panelMain.add(labelStatus, new GridConstraints(1, 0, 1, 1, GridConstraints.ANCHOR_WEST, GridConstraints.FILL_NONE, GridConstraints.SIZEPOLICY_FIXED, GridConstraints.SIZEPOLICY_FIXED, null, null, null, 0, false));
    }

    /**
     * @noinspection ALL
     */
    public JComponent $$$getRootComponent$$$() {
        return panelMain;
    }

}
