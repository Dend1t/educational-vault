//2. Для набора линий вида ax + by + c = 0 найти ближайшую к началу координат точку
//пересечения двух произвольных линий из набора. Также указать, какие линии из набора
//при пересечении дают такую точку. В случае существования нескольких ближайших к
//началу координат точек пересечения – выбрать произвольную.
package ru.vsu.cs.course1;


public class Task {
    public static double[][] closestPoint(double[][] arr) {
        double minLength = Double.POSITIVE_INFINITY;
        double[][] answer = new double[][]{
                {0, 0, 0},
                {0, 0, 0},
                {0, 0, Double.POSITIVE_INFINITY}};
        for (int i = 0; i < arr.length; i++) {
            for (int z = i + 1; z < arr.length; z++) {
                Line line1 = new Line(arr[i][0], arr[i][1], arr[i][2]);
                Line line2 = new Line(arr[z][0], arr[z][1], arr[z][2]);
                Point point = Point.calcPoint(line1, line2);
                if (point.length < minLength) {
                    minLength = point.length;
                    answer = new double[][]{
                            {line1.a, line1.b, line1.c},
                            {line2.a, line2.b, line2.c},
                            {point.x, point.y, point.length}};
                }
            }
        }
        return answer;
    }

    public static class Line {
        public double a;
        public double b;
        public double c;

        public Line(double a, double b, double c) {
            this.a = a;
            this.b = b;
            this.c = c;
        }
    }

    public static class Point {
        public double x;
        public double y;
        public double length;

        public Point(double x, double y, double length) {
            this.x = x;
            this.y = y;
            this.length = length;
        }

        public static Point defaultPoint() {
            return new Point(0, 0, Double.POSITIVE_INFINITY);
        }

        public static Point calcPoint(Line line1, Line line2) {
            double delta = line1.a * line2.b - line2.a * line2.b;

            if (delta != 0) {
                double x = (line1.b * line2.c - line2.b * line1.c) / delta;
                double y = (line2.a * line1.c - line1.a * line2.c) / delta;
                return new Point(x, y, Math.sqrt(x * x + y * y));
            } else {
                return Point.defaultPoint();
            }
        }
    }
}
